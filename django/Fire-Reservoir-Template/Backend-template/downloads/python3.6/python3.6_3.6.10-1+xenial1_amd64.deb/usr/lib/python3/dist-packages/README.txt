This directory exists so that 3rd party packages can be installed
here.  Read the source for site.py for more details.
